package ru.fa.internetshop.entity;

public enum OrderStatus {
    NEW,
    CONFIRMED,
    CANCELLED
}
